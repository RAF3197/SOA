#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int
Connection (char *host_name, int port)
{

  struct sockaddr_in serv_addr;
  struct hostent * hent;
  int socket_fd;
  int ret;

  //creates the virtual device for accessing the socket
  socket_fd = socket (AF_INET, SOCK_STREAM, 0);
  if (socket_fd < 0)
    return socket_fd;

  //memset((char *) &serv_addr, 0, sizeof(serv_addr));

  serv_addr.sin_family = AF_INET;
  hent = gethostbyname(host_name);
  if (hent == NULL) {
        close (socket_fd);
	return -1;

  }
  //memcpy((char *)&serv_addr.sin_addr.s_addr, (char *) hent->h_addr, hent->h_length);
  serv_addr.sin_port = htons(port);
  serv_addr.sin_family = PF_INET; 

  ret = connect (socket_fd, (struct sockaddr *) &serv_addr, sizeof (serv_addr));
  if (ret < 0)
  {
	  close (socket_fd);
	  return (ret);
  } 

  return socket_fd;

}



main (int argc, char *argv[])
{
  int inicial, final, processos;
  int socketFD;
  int connectionFD;
  char buff[80];
  int count=0;
  int rang_ports;
  int paquets_proc;

  if (argc != 4)
  {
    sprintf (buff, "Usage: %s machine_ip 4500 6000\n", argv[0]);
    write (2, buff, strlen (buff));
    exit (1);
  } 
  inicial = atoi(argv[2]);
  final = atoi (argv[3]);
  rang_ports=(final-(inicial-1));
  count = rang_ports%10;
  if(rang_ports<10) {
	paquets_proc = 1;
	processos=rang_ports;
  }
  else {
	paquets_proc=rang_ports/10;
        processos=10;
  }
  int padre = 0;
  //int hermano = NULL;
  int f;
  int pid = -1;
  int in, fi;
  for(f=0; f<processos && pid!=0; ++f) {
    pid = fork();
    if(pid==0) {
       padre = -1;
       if(count>0) 
       in = inicial + f*paquets_proc;
       fi = in + paquets_proc;
    }
  }
  
if(padre == -1) {
  int port;
  for(port = in; port<fi; ++port) {
   		  connectionFD = Connection (argv[1], port);
		  if(connectionFD<0) {
			sprintf (buff, "El %d port esta Tancat\n", port);
	    		write (1, buff, strlen (buff));
		  }
		  else 	{
			sprintf (buff, "El %d port esta OBERTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT\n", port);
	    		write (1, buff, strlen (buff));
	       		++count;
		  }
}
sprintf (buff, "hey: %d, %d \n", in, fi, getpid());
write (1, buff, strlen (buff));
}

}
