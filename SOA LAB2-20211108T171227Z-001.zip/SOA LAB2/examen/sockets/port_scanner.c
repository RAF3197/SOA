#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/resource.h>
#include <sys/time.h>


comprobarRangoPuerto(rangI, rango) {
  int connectionFD;
  int ret;
  int comprobado[rango];
  for(int i = rangI; i<= rango ;++i){
    connectionFD = clientConnection (server, puerto);
    if (connectionFD < 0)
    {
      
      comprobados[port] = -1;
    }
    else comprobados[port] = 0;
    close (connectionFD);
  }
}

main (int argc, char *argv[])
{
  int r;
  char buff[80];
  char buff2[80];
  char *server;
  int inicial, final;

  if (argc != 4)
  {
    sprintf (buff, "Usage: %s machine_ip 4500 6000\n", argv[0]);
    write (2, buff, strlen (buff));
    exit (1);
  }

  server = argv[1];
  inicial = atoi(argv[2]);
  final = atoi (argv[3]);
  if
/*
  connectionFD = clientConnection (server, puerto);
  if (connectionFD < 0)
  {
      perror ("Error establishing connection\n");
      exit (1);
  }

  sprintf(buff2, "%i %s", numero_cliente, mensaje);
  ret = write (connectionFD, buff2 ,sizeof (buff2));

  if (ret < 0)
  {
	  perror ("Error writing to connection\n");
	  exit (1);
  }
*/
  int c = inicial - final;
  int rango = c/10; //los rangos de un hijo, maximo 10hijos 
  for(int i = 0; i<10;++i){
    int f = fork();
    if(f==0) {//hijo
      comprobarRangoPuerto(i*rango, rango)
      exit(0);
    }
  }


  while(1){
    ret = read (connectionFD, buff, sizeof (buff));
    if (ret < 0)
    {
  	  perror ("Error reading on connection\n");
  	  exit (1);
    }
    if(buff == "no") {
        sprintf (buff2, "\nClient [%d] finishes\n", getpid());
        write(1,buff2,strlen(buff2));
        deleteSocket (connectionFD);
        exit(0);
    }
    else{
      buff[ret] = '\0';
      sprintf (buff2, "Client [%d] received: %s\n",getpid(), buff);
      write(1,buff2,strlen(buff2));
    }
  }


}
