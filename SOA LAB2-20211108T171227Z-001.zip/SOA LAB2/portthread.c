
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h>

struct hostent * hent;

int vec[];
int
Connection (int port)
{

  struct sockaddr_in serv_addr;

  int socket_fd;
  int ret;

  //creates the virtual device for accessing the socket
  socket_fd = socket (AF_INET, SOCK_STREAM, 0);
  if (socket_fd < 0)
    return socket_fd;

  memset((char *) &serv_addr, 0, sizeof(serv_addr));

  serv_addr.sin_family = AF_INET;
  	
  if (hent == NULL) {
        close (socket_fd);
	return -1;

  }

  memcpy((char *)&serv_addr.sin_addr.s_addr, (char *) hent->h_addr, hent->h_length);
  serv_addr.sin_port = htons(port);
  serv_addr.sin_family = PF_INET; 

  ret = connect (socket_fd, (struct sockaddr *) &serv_addr, sizeof (serv_addr));
  if (ret < 0)
  {
	  close (socket_fd);
	  return (ret);
  } 

  return socket_fd;

}

void *acceptar(void * parm) {
	int *param = (int *) parm;
	int port;
	int connectionFD;
	char buff[80];
        int in1=param[0];
	int fi1=param[1];
	
	for(port = in1; port < fi1; ++port) {
   		  connectionFD = Connection(port);
		  if(connectionFD>0) vec[port]=port;
	}
		 
	
}

main (int argc, char *argv[])
{
  int inicial, final, total, limit;
  int socketFD;
  char buff[80];
  int count=-1;
  int rango;
  if (argc != 4)
  {
    sprintf (buff, "Usage: %s machine_ip 4500 6000\n", argv[0]);
    write (2, buff, strlen (buff));
    exit (1);
  } 


  inicial = atoi(argv[2]);
  final = atoi (argv[3]);
  total=(final-(inicial-1));
  vec[final];
  hent = gethostbyname(argv[1]);

  if(total<10) {
	rango = 1;
	limit=total;
  }
  else {
	rango=total/10;
        limit=10;
	count=total%10;
  }
  if(count==0) count=-1;

  int f, fd, i, a, in, fi;
  pthread_t thread[limit];
    sprintf (buff, "El port esta Tancat\n");
		    	write (1, buff, strlen (buff));
  int *param = (int *)malloc(2* sizeof(int));
  //for(i=inicial-1; i<final; ++i) vec[i]=NULL;
  for(f=0; f<limit; ++f) {
    //param[0]=0;
    //param[1]=0;	
    if(f==0) {
       in = inicial;
       fi = in + rango;
    }
    else {
       in = fi;
       fi += rango;
    }  
    if(count>0) {
       fi++;
       --count;
    }
    param[0]=in;
    param[1]=fi;
    
    a = pthread_create(&thread[f], NULL, acceptar, (void *) param);
  
  }
int it;

for(it=0;it<limit;++it) {
	pthread_join(&thread[it], NULL);
        //pthread_exit(&thread[it]);
       
}
for(it = inicial; it<=final; ++it) {
		if(vec[it]==NULL) {
			sprintf (buff, "El %d port esta Tancat\n", it);
		    	write (1, buff, strlen (buff));
		}
		else 	{
			sprintf (buff, "El %d port esta OBERTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT\n", vec[it]);
		    	write (1, buff, strlen (buff));

		}

	}


}

