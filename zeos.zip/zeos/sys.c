/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1

extern int zeos_ticks;

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int sys_fork()
{
  int PID=-1;

  // creates the child process
  
  return PID;
}

void sys_exit()
{  
}

int sys_write(int fd, char * buffer, int size){
  
  int size_total = size;
  int i = check_fd(fd, ESCRIPTURA);
  if (buffer == NULL) return -1;
  if (size<0)return -1;
  if (i!=0)return i;
  char buff[4];
  int bytes_escritos = 0;
  while(size>=4){
    i = copy_from_user(buffer,buff,4);
    bytes_escritos += sys_write_console(buff,4);
    size -=4;
    buffer +=4;
  }
  i = copy_from_user(buffer,buff,4);
  bytes_escritos += sys_write_console(buff,4);
  return bytes_escritos;
}

int sys_time(){
  return zeos_ticks;
}